CMAKE_<LANG>_LINK_LIBRARY_FILE_FLAG
-----------------------------------

.. versionadded:: 3.16

Language-specific flag to be used to link a library specified by
a path to its file.

The flag will be used before a library file path is given to the
linker.  This is needed only on very few platforms.
