CMAKE_JOB_POOLS
---------------

.. versionadded:: 3.11

If the :prop_gbl:`JOB_POOLS` global property is not set, the value
of this variable is used in its place.  See :prop_gbl:`JOB_POOLS`
for additional information.
