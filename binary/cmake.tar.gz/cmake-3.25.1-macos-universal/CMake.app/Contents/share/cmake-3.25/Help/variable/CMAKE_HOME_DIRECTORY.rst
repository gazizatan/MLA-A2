CMAKE_HOME_DIRECTORY
--------------------

Path to top of source tree. Same as :variable:`CMAKE_SOURCE_DIR`.

This is an internal cache entry used to locate the source directory
when loading a ``CMakeCache.txt`` from a build tree.  It should not
be used in project code.  The variable :variable:`CMAKE_SOURCE_DIR`
has the same value and should be preferred.
