CMAKE_<LANG>_VISIBILITY_PRESET
------------------------------

Default value for the :prop_tgt:`<LANG>_VISIBILITY_PRESET` target
property when a target is created.
