CMAKE_CUDA_STANDARD_REQUIRED
----------------------------

.. versionadded:: 3.8

Default value for :prop_tgt:`CUDA_STANDARD_REQUIRED` target property if set
when a target is created.

See the :manual:`cmake-compile-features(7)` manual for information on
compile features and a list of supported compilers.
